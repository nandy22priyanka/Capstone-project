package com.greatlearning.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Discount")

public class Discount {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(nullable = false , unique = true)
	private Long discountId;
	
	@Column(nullable = false, length = 25)
	private String discountName;
	
	@Column(nullable = false)
	private Float discountPercentage;
	
	
	@Column(nullable = false)
	private Date createTime;
	

	private Date updateTime;
	
	@OneToOne(mappedBy = "discount")
    private Product product;

	

	public Long getDiscountId() {
		return discountId;
	}

	public void setDiscountId(Long discountId) {
		this.discountId = discountId;
	}

	public String getDiscountName() {
		return discountName;
	}

	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}

	public Float getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(Float discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Discount [discountId=" + discountId + ", discountName=" + discountName + ", discountPercentage="
				+ discountPercentage + ", createTime=" + createTime + ", updateTime=" + updateTime + ", product="
				+ product + "]";
	}

}
