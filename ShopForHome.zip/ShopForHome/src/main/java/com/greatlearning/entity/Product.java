package com.greatlearning.entity;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="product")

public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(nullable = false , unique = true)
	private int productId;
	
	@Column(nullable = false ,length = 25)
	private String productName;
	
	@Column(nullable = false , length = 100)
	private String productDescription;
	
	@Column(nullable = false )
	private Double productprice;
	
	@Column(nullable = false)
	private int productStock;
	
	@Column(nullable = false)
	private String productImg;
	

	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "productCategory", referencedColumnName ="categoryId")
    private ProductCategory productcategory;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Discount", referencedColumnName ="discountId")
    private Discount discount;
	
	@OneToMany(mappedBy = "product")
	private Set<Cart> cart;
  
	
	@OneToMany(mappedBy = "product")
    private Set<Wishlist> wishlist;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public Double getProductprice() {
		return productprice;
	}

	public void setProductprice(Double productprice) {
		this.productprice = productprice;
	}

	public int getProductStock() {
		return productStock;
	}

	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}

	public String getProductImg() {
		return productImg;
	}

	public void setProductImg(String productImg) {
		this.productImg = productImg;
	}

	public ProductCategory getProductcategory() {
		return productcategory;
	}

	public void setProductcategory(ProductCategory productcategory) {
		this.productcategory = productcategory;
	}

	public Discount getDiscount() {
		return discount;
	}

	public Set<Cart> getCart() {
		return cart;
	}

	public void setCart(Set<Cart> cart) {
		this.cart = cart;
	}

	public Set<Wishlist> getWishlist() {
		return wishlist;
	}

	public void setWishlist(Set<Wishlist> wishlist) {
		this.wishlist = wishlist;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productDescription="
				+ productDescription + ", productprice=" + productprice + ", productStock=" + productStock
				+ ", productImg=" + productImg + ", productcategory=" + productcategory + ", discount=" + discount
				+ ", cart=" + cart + ", wishlist=" + wishlist + "]";
	}
	
	
	
	
	


}
