package com.greatlearning.entity;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Wishlist")

public class Wishlist {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(nullable = false , unique = true)
	private Long wishlistId;
	
	public Long getWishlistId() {
		return wishlistId;
	}

	public void setWishlistId(Long wishlistId) {
		this.wishlistId = wishlistId;
	}

	@Column(nullable = false)
	private Date createTime;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "User", referencedColumnName ="userId")
    private User user;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Product", referencedColumnName ="productId")
    private Product product;

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Wishlist [wishlistId=" + wishlistId + ", createTime=" + createTime + ", user=" + user + ", product="
				+ product + "]";
	}

	
}
