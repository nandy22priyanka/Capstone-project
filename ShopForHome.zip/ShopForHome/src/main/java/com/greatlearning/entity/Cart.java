package com.greatlearning.entity;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Cart")

public class Cart {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(nullable = false , unique = true)
	private Long cartId;
	
	@Column(nullable = false)
	private int quantity;
	
	@Column(nullable = false)
	private double total;
	
	@Column(nullable = false)
	private Date createTime;
	
	@Column(nullable = false)
	private Date UpdateTime;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "User", referencedColumnName ="userId")
    private User user;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Product", referencedColumnName ="productId")
    private Product product;

	public Long getCartId() {
		return cartId;
	}

	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return UpdateTime;
	}

	public void setUpdateTime(Date updateTime) {
		UpdateTime = updateTime;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", quantity=" + quantity + ", total=" + total + ", createTime=" + createTime
				+ ", UpdateTime=" + UpdateTime + ", user=" + user + ", product=" + product + "]";
	}
	
	
}
